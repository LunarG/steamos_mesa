This directory contains a Windows binary for the glslang validator.

Installation: The executable in this directory is self sufficient, and can be 
placed where desired; in a test directory, or in a system path, etc.

Usage:  Execute glslangValidator with no arguments to get a usage statement.
