// The file revision.h should be updated to the latest version, somehow, on 
// check-in, if glslang has changed.
//
// revision.template is the source for revision.h when using SubWCRev as the
// method of updating revision.h.  You don't have to do it this way, the
// requirement is only that revision.h gets updated.
//
// revision.h is under source control so that not all consumers of glslang
// source have to figure out how to create revision.h just to get a build
// going.  However, if it is not updated, it can be a version behind.

#define GLSLANG_REVISION "25512"
#define GLSLANG_DATE     "2014/02/24 14:36:08"
